#ifndef __PRE_H
#define __PRE_H
#include <stdio.h>
int pre(FILE* input, FILE* output);
int pred(FILE* input, FILE* output);
#endif